<?php
    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $db = 'proj_emsc';

    $conn = mysqli_connect($host, $user, $pass, $db) or die ('Could not connect !');
?>