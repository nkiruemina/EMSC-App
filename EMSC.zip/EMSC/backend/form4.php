<?php
	require_once 'db.php';

	$form_questionnaire_name = mysqli_real_escape_string($db, $_POST['form_questionnaire_name']);
    $form_questionnaire_gender = mysqli_real_escape_string($db, $_POST['form_questionnaire_gender']);
    $form_questionnaire_lga = mysqli_real_escape_string($db, $_POST['form_questionnaire_lga']);

    $form_questionnaire_community = mysqli_real_escape_string($db, $_POST['form_questionnaire_community']);
    $form_questionnaire_senatorial = mysqli_real_escape_string($db, $_POST['form_questionnaire_senatorial']);
    //
    $form_questionnaire_name = mysqli_real_escape_string($db, $_POST['form_questionnaire_name']);
    $form_questionnaire_gender = mysqli_real_escape_string($db, $_POST['form_questionnaire_gender']);
    $form_questionnaire_lga = mysqli_real_escape_string($db, $_POST['form_questionnaire_lga']);

    $form_questionnaire_community = mysqli_real_escape_string($db, $_POST['form_questionnaire_community']);
    $form_questionnaire_senatorial = mysqli_real_escape_string($db, $_POST['form_questionnaire_senatorial']);
    //
    $form_questionnaire_1 = mysqli_real_escape_string($db, $_POST['form_questionnaire_1']);
    $form_questionnaire_2 = mysqli_real_escape_string($db, $_POST['form_questionnaire_2']);
    $form_questionnaire_3 = mysqli_real_escape_string($db, $_POST['form_questionnaire_3']);
    $form_questionnaire_4 = mysqli_real_escape_string($db, $_POST['form_questionnaire_4']);
    $form_questionnaire_5 = mysqli_real_escape_string($db, $_POST['form_questionnaire_5']);
    $form_questionnaire_6 = mysqli_real_escape_string($db, $_POST['form_questionnaire_6']);
    $form_questionnaire_7 = mysqli_real_escape_string($db, $_POST['form_questionnaire_7']);
    $form_questionnaire_8 = mysqli_real_escape_string($db, $_POST['form_questionnaire_8']);
    $form_questionnaire_9 = mysqli_real_escape_string($db, $_POST['form_questionnaire_9']);
    $form_questionnaire_10 = mysqli_real_escape_string($db, $_POST['form_questionnaire_10']);
    $form_questionnaire_11 = mysqli_real_escape_string($db, $_POST['form_questionnaire_11']);
    $form_questionnaire_12 = mysqli_real_escape_string($db, $_POST['form_questionnaire_12']);
    $form_questionnaire_13 = mysqli_real_escape_string($db, $_POST['form_questionnaire_13']);
    $form_questionnaire_14 = mysqli_real_escape_string($db, $_POST['form_questionnaire_14']);
    $form_questionnaire_15 = mysqli_real_escape_string($db, $_POST['form_questionnaire_15']);
    $form_questionnaire_16 = mysqli_real_escape_string($db, $_POST['form_questionnaire_16']);
    $form_questionnaire_17 = mysqli_real_escape_string($db, $_POST['form_questionnaire_17']);
    $form_questionnaire_18 = mysqli_real_escape_string($db, $_POST['form_questionnaire_18']);
    $form_questionnaire_19 = mysqli_real_escape_string($db, $_POST['form_questionnaire_19']);
    $form_questionnaire_20 = mysqli_real_escape_string($db, $_POST['form_questionnaire_20']);
    //
    $form_questionnaire_21 = mysqli_real_escape_string($db, $_POST['form_questionnaire_21']);
    $form_questionnaire_22 = mysqli_real_escape_string($db, $_POST['form_questionnaire_22']);
    $form_questionnaire_23 = mysqli_real_escape_string($db, $_POST['form_questionnaire_23']);
    $form_questionnaire_24 = mysqli_real_escape_string($db, $_POST['form_questionnaire_24']);
    $form_questionnaire_25 = mysqli_real_escape_string($db, $_POST['form_questionnaire_25']);
    $form_questionnaire_26 = mysqli_real_escape_string($db, $_POST['form_questionnaire_26']);
    $form_questionnaire_27 = mysqli_real_escape_string($db, $_POST['form_questionnaire_27']);
    $form_questionnaire_28 = mysqli_real_escape_string($db, $_POST['form_questionnaire_28']);
    $form_questionnaire_29 = mysqli_real_escape_string($db, $_POST['form_questionnaire_29']);
    $form_questionnaire_30 = mysqli_real_escape_string($db, $_POST['form_questionnaire_30']);
    $form_questionnaire_31 = mysqli_real_escape_string($db, $_POST['form_questionnaire_31']);
    $form_questionnaire_32 = mysqli_real_escape_string($db, $_POST['form_questionnaire_32']);
    $form_questionnaire_33 = mysqli_real_escape_string($db, $_POST['form_questionnaire_33']);
    $form_questionnaire_34 = mysqli_real_escape_string($db, $_POST['form_questionnaire_34']);
    $form_questionnaire_35 = mysqli_real_escape_string($db, $_POST['form_questionnaire_35']);
    $form_questionnaire_36 = mysqli_real_escape_string($db, $_POST['form_questionnaire_36']);
    $form_questionnaire_37 = mysqli_real_escape_string($db, $_POST['form_questionnaire_37']);
    $form_questionnaire_38 = mysqli_real_escape_string($db, $_POST['form_questionnaire_38']);
    $form_questionnaire_39 = mysqli_real_escape_string($db, $_POST['form_questionnaire_39']);
    $form_questionnaire_40 = mysqli_real_escape_string($db, $_POST['form_questionnaire_40']);
    //
    $form_questionnaire_41 = mysqli_real_escape_string($db, $_POST['form_questionnaire_41']);
    $form_questionnaire_42 = mysqli_real_escape_string($db, $_POST['form_questionnaire_42']);
    $form_questionnaire_43 = mysqli_real_escape_string($db, $_POST['form_questionnaire_43']);
    $form_questionnaire_44 = mysqli_real_escape_string($db, $_POST['form_questionnaire_44']);
    $form_questionnaire_45 = mysqli_real_escape_string($db, $_POST['form_questionnaire_45']);
    $form_questionnaire_46 = mysqli_real_escape_string($db, $_POST['form_questionnaire_46']);
    $form_questionnaire_47 = mysqli_real_escape_string($db, $_POST['form_questionnaire_47']);
    $form_questionnaire_48 = mysqli_real_escape_string($db, $_POST['form_questionnaire_48']);
    $form_questionnaire_49 = mysqli_real_escape_string($db, $_POST['form_questionnaire_49']);
    $form_questionnaire_50 = mysqli_real_escape_string($db, $_POST['form_questionnaire_50']);
    $form_questionnaire_51 = mysqli_real_escape_string($db, $_POST['form_questionnaire_51']);
    $form_questionnaire_52 = mysqli_real_escape_string($db, $_POST['form_questionnaire_52']);
    $form_questionnaire_53 = mysqli_real_escape_string($db, $_POST['form_questionnaire_53']);
    $form_questionnaire_54 = mysqli_real_escape_string($db, $_POST['form_questionnaire_54']);
    $form_questionnaire_55 = mysqli_real_escape_string($db, $_POST['form_questionnaire_55']);
    $form_questionnaire_56 = mysqli_real_escape_string($db, $_POST['form_questionnaire_56']);
    $form_questionnaire_57 = mysqli_real_escape_string($db, $_POST['form_questionnaire_57']);
    $form_questionnaire_58 = mysqli_real_escape_string($db, $_POST['form_questionnaire_58']);
    $form_questionnaire_59 = mysqli_real_escape_string($db, $_POST['form_questionnaire_59']);
    $form_questionnaire_60 = mysqli_real_escape_string($db, $_POST['form_questionnaire_60']);
    //
    $form_questionnaire_61 = mysqli_real_escape_string($db, $_POST['form_questionnaire_61']);
    $form_questionnaire_62 = mysqli_real_escape_string($db, $_POST['form_questionnaire_62']);
    $form_questionnaire_63 = mysqli_real_escape_string($db, $_POST['form_questionnaire_63']);
    $form_questionnaire_64 = mysqli_real_escape_string($db, $_POST['form_questionnaire_64']);
    $form_questionnaire_65 = mysqli_real_escape_string($db, $_POST['form_questionnaire_65']);
    $form_questionnaire_66 = mysqli_real_escape_string($db, $_POST['form_questionnaire_66']);
    $form_questionnaire_67 = mysqli_real_escape_string($db, $_POST['form_questionnaire_67']);
    $form_questionnaire_68 = mysqli_real_escape_string($db, $_POST['form_questionnaire_68']);
    $form_questionnaire_69 = mysqli_real_escape_string($db, $_POST['form_questionnaire_69']);
    $form_questionnaire_70 = mysqli_real_escape_string($db, $_POST['form_questionnaire_70']);
	$timestamp = time() + (60*60*1);

	if($form_questionnaire_62 != '0' and $form_questionnaire_63 != '0' and $form_questionnaire_64 != '0' and $form_questionnaire_65 != '0' and $form_questionnaire_66 != '0' and $form_questionnaire_67 != '0' and $form_questionnaire_68 != '0' and $form_questionnaire_69 != '0' and $form_questionnaire_70 != '0') {
			
		mysqli_query($db,"INSERT INTO form_04 SET form_questionnaire_name='$form_questionnaire_name', form_questionnaire_gender='$form_questionnaire_gender', form_questionnaire_community='$form_questionnaire_community', form_questionnaire_senatorial='$form_questionnaire_senatorial', form_questionnaire_lga='$form_questionnaire_lga', form_questionnaire_1='$form_questionnaire_1', form_questionnaire_2='$form_questionnaire_2', form_questionnaire_3='$form_questionnaire_3', form_questionnaire_4='$form_questionnaire_4', form_questionnaire_5='$form_questionnaire_5', form_questionnaire_6='$form_questionnaire_6', form_questionnaire_7='$form_questionnaire_7', form_questionnaire_8='$form_questionnaire_8', form_questionnaire_9='$form_questionnaire_9', form_questionnaire_10='$form_questionnaire_10', form_questionnaire_11='$form_questionnaire_11', form_questionnaire_12='$form_questionnaire_12', form_questionnaire_13='$form_questionnaire_13', form_questionnaire_14='$form_questionnaire_14', form_questionnaire_15='$form_questionnaire_15', form_questionnaire_16='$form_questionnaire_16', form_questionnaire_17='$form_questionnaire_17', form_questionnaire_18='$form_questionnaire_18', form_questionnaire_19='$form_questionnaire_19', form_questionnaire_20='$form_questionnaire_20', form_questionnaire_21='$form_questionnaire_21', form_questionnaire_22='$form_questionnaire_22', form_questionnaire_23='$form_questionnaire_23', form_questionnaire_24='$form_questionnaire_24', form_questionnaire_25='$form_questionnaire_25', form_questionnaire_26='$form_questionnaire_26', form_questionnaire_27='$form_questionnaire_27', form_questionnaire_28='$form_questionnaire_28', form_questionnaire_29='$form_questionnaire_29', form_questionnaire_30='$form_questionnaire_30', form_questionnaire_31='$form_questionnaire_31', form_questionnaire_32='$form_questionnaire_32', form_questionnaire_33='$form_questionnaire_33', form_questionnaire_34='$form_questionnaire_34', form_questionnaire_35='$form_questionnaire_35', form_questionnaire_36='$form_questionnaire_36', form_questionnaire_37='$form_questionnaire_37', form_questionnaire_38='$form_questionnaire_38', form_questionnaire_39='$form_questionnaire_39', form_questionnaire_40='$form_questionnaire_40', form_questionnaire_41='$form_questionnaire_41', form_questionnaire_42='$form_questionnaire_42', form_questionnaire_43='$form_questionnaire_43', form_questionnaire_44='$form_questionnaire_44', form_questionnaire_45='$form_questionnaire_45', form_questionnaire_46='$form_questionnaire_46', form_questionnaire_47='$form_questionnaire_47', form_questionnaire_48='$form_questionnaire_48', form_questionnaire_49='$form_questionnaire_49', form_questionnaire_50='$form_questionnaire_50', form_questionnaire_51='$form_questionnaire_51', form_questionnaire_52='$form_questionnaire_52', form_questionnaire_53='$form_questionnaire_53', form_questionnaire_54='$form_questionnaire_54', form_questionnaire_55='$form_questionnaire_55', form_questionnaire_56='$form_questionnaire_56', form_questionnaire_57='$form_questionnaire_57', form_questionnaire_58='$form_questionnaire_58', form_questionnaire_59='$form_questionnaire_59', form_questionnaire_60='$form_questionnaire_60', form_questionnaire_61='$form_questionnaire_61', form_questionnaire_62='$form_questionnaire_62', form_questionnaire_63='$form_questionnaire_63', form_questionnaire_64='$form_questionnaire_64', form_questionnaire_65='$form_questionnaire_65', form_questionnaire_66='$form_questionnaire_66', form_questionnaire_67='$form_questionnaire_67', form_questionnaire_68='$form_questionnaire_68', form_questionnaire_69='$form_questionnaire_69', form_questionnaire_70='$form_questionnaire_70', form_date_created=$timestamp, form_field_agent='Nkiru Agent'");

			if($query) {
				$reply = array(
					'Type' => 'success',
					'Reply' => 'Form saved successfully !'
				);
				exit(json_encode($reply));
			} else {
				$reply = array(
					'Type' => 'error',
					'Reply' => 'Server is under constructions! Please try again later.'
				);
				exit(json_encode($reply));
			}
	} else {
		$reply = array(
			'Type' => 'fill',
			'Reply' => 'Please answer all the questions.'
		);
		exit(json_encode($reply));
	}
?>